"""
MIKAGE PIPELINE — config.py
Loads .env from project root, exposes settings.
NEVER logs or prints API keys.
"""

import os
import logging
from pathlib import Path
from dotenv import load_dotenv

log = logging.getLogger("mikage.config")

# ── Locate project root and load .env ──
# Works whether called from pipeline/ or from root
_this_dir = Path(__file__).resolve().parent
PROJECT_ROOT = _this_dir.parent  # D:\KAGAMI-MZ
ENV_FILE = PROJECT_ROOT / ".env"

if ENV_FILE.exists():
    load_dotenv(ENV_FILE, override=True)
    log.info(f".env loaded from {ENV_FILE}")
else:
    log.warning(f".env NOT found at {ENV_FILE}")

# ── API Keys (presence check only) ──
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY", "")
GOOGLE_AI_KEY  = os.getenv("GOOGLE_AI_KEY", "")

def get_gemini_key() -> str:
    """Return the first available Gemini key."""
    for k in [GEMINI_API_KEY, GOOGLE_API_KEY, GOOGLE_AI_KEY]:
        if k:
            return k
    raise RuntimeError("No Gemini API key found in .env")

def log_key_presence():
    """Log boolean presence of keys — NEVER the values."""
    log.info(f"GEMINI_API_KEY present = {bool(GEMINI_API_KEY)}")
    log.info(f"GOOGLE_API_KEY present = {bool(GOOGLE_API_KEY)}")
    log.info(f"GOOGLE_AI_KEY  present = {bool(GOOGLE_AI_KEY)}")

# ── Fooocus Proxy ──
FOOOCUS_PROXY_URL = os.getenv("FOOOCUS_PROXY_URL", "http://127.0.0.1:7866")

# ── Paths ──
RUNS_DIR = PROJECT_ROOT / "runs"
RUNS_DIR.mkdir(parents=True, exist_ok=True)

PIPELINE_DIR = _this_dir

# ── Canon thresholds ──
CRIMSON_HEX = "#E60000"
PORCELAIN_BG = "#FAFAFA"
OBSIDIAN_BG = "#0A0A0A"
CHIAROSCURO_RATIO = 4.0  # shadow:light ~4:1

# ── Gemini model ──
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
GEMINI_VISION_MODEL = os.getenv("GEMINI_VISION_MODEL", "gemini-2.0-flash")
