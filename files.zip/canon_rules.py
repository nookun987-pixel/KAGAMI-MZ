"""
MIKAGE PIPELINE — canon_rules.py
Visual canon definitions for the Mikage Zenith brand.
Each rule has:
  - code (T1, T2, ...)
  - name
  - check_type: "pixel" (automated) or "semantic" (Gemini vision)
  - hard_fail: True = instant REJECT
  - description
"""

CANON_RULES = {
    # ── SUBJECT ──
    "T1": {
        "name": "ENGINEERED_ENTITY",
        "check_type": "semantic",
        "hard_fail": False,
        "description": "Subject must be engineered entity (kitsune mask porcelain, industrial blade). Not organic, not human.",
    },
    "T2": {
        "name": "NO_HUMAN_EYES",
        "check_type": "pixel",
        "hard_fail": True,
        "field": "human_eyes_detected",
        "threshold": 0,
        "description": "Zero human eyes detected. Mask slits OK, but no iris/pupil/sclera.",
    },
    "T3": {
        "name": "NO_EXPRESSION",
        "check_type": "semantic",
        "hard_fail": False,
        "description": "No facial expression. Mask is inert, not emoting.",
    },

    # ── MATERIAL ──
    "T4": {
        "name": "CERAMIC_PORCELAIN",
        "check_type": "semantic",
        "hard_fail": False,
        "description": "Material reads as real ceramic/porcelain. Not plastic, not plaster, not CGI-smooth.",
    },
    "T5": {
        "name": "NO_PVC_PLASTIC",
        "check_type": "pixel",
        "hard_fail": True,
        "field": "pvc_plastic_read",
        "threshold": 0,
        "description": "Zero PVC/plastic surface reading.",
    },
    "T6": {
        "name": "NO_TOON_SHADING",
        "check_type": "pixel",
        "hard_fail": True,
        "field": "toon_shading",
        "threshold": 0,
        "description": "Zero cel/toon shading. Must be photorealistic lighting.",
    },

    # ── COLOR ──
    "T7": {
        "name": "CRIMSON_SEAM_ONLY",
        "check_type": "pixel",
        "hard_fail": False,
        "field": "crimson_ratio",
        "threshold_max": 0.08,
        "description": "Crimson #E60000 appears only at seams/core, max 8% of image area. No bloom.",
    },
    "T8": {
        "name": "BG_PORCELAIN_OR_OBSIDIAN",
        "check_type": "semantic",
        "hard_fail": False,
        "description": "Background porcelain #FAFAFA or obsidian #0A0A0A. Not pure white #FFFFFF, not pure black #000000.",
    },

    # ── LIGHTING ──
    "T9": {
        "name": "CHIAROSCURO_RATIO",
        "check_type": "pixel",
        "hard_fail": False,
        "field": "shadow_ratio",
        "description": "Chiaroscuro ~4:1, shadow occupies majority of frame.",
    },
    "T10": {
        "name": "NO_NEON_RGB",
        "check_type": "pixel",
        "hard_fail": False,
        "field": "magenta_neon_spill",
        "threshold": 0,
        "description": "No neon RGB, no cyberpunk color spill.",
    },

    # ── COMPOSITION ──
    "T11": {
        "name": "NO_ABSTRACT_FRAME",
        "check_type": "semantic",
        "hard_fail": True,
        "description": "Must read as clear manufactured object. No abstract art, no unrecognizable shapes.",
    },
    "T12": {
        "name": "MATERIAL_PRESENT",
        "check_type": "semantic",
        "hard_fail": True,
        "description": "Object material must be clearly readable. No MATERIAL_ABSENT.",
    },
    "T13": {
        "name": "NEGATIVE_SPACE",
        "check_type": "semantic",
        "hard_fail": False,
        "description": "Clear negative space around subject. Not cluttered.",
    },
    "T14": {
        "name": "GEOMETRY_CORRECT",
        "check_type": "semantic",
        "hard_fail": False,
        "description": "Mask symmetry correct, blade perfectly straight. No physics distortion.",
    },

    # ── PIXEL CHECKS ──
    "T15": {
        "name": "NO_LOGO_OVERLAP",
        "check_type": "pixel",
        "hard_fail": False,
        "field": "logo_overlap_ratio",
        "threshold": 0,
        "description": "No logo/watermark overlap on subject.",
    },
    "T16": {
        "name": "LOW_ENERGY_TONE",
        "check_type": "pixel",
        "hard_fail": False,
        "field": "edge_activity",
        "description": "Low energy, high control aesthetic. Calm edges, controlled luminance.",
    },
}

HARD_FAIL_CODES = [code for code, rule in CANON_RULES.items() if rule["hard_fail"]]
# = ["T2", "T5", "T6", "T11", "T12"]

PIXEL_RULES = {code: rule for code, rule in CANON_RULES.items() if rule["check_type"] == "pixel"}
SEMANTIC_RULES = {code: rule for code, rule in CANON_RULES.items() if rule["check_type"] == "semantic"}


def build_canon_checklist_prompt() -> str:
    """Build a prompt fragment listing all canon rules for Gemini to check."""
    lines = ["Check this image against each visual canon rule and report PASS or FAIL:\n"]
    for code, rule in CANON_RULES.items():
        if rule["check_type"] == "semantic":
            lines.append(f"- {code} ({rule['name']}): {rule['description']}")
    lines.append("\nRespond in JSON: {\"checks\": [{\"code\": \"T1\", \"pass\": true/false, \"reason\": \"...\"}]}")
    return "\n".join(lines)
