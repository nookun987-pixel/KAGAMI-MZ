"""
MIKAGE PIPELINE — gemini_gate.py
Gemini vision final gate: sends rendered image + canon checklist,
receives ALLOW or REJECT with structured reasoning.
"""

import json
import base64
import logging
import requests
from pathlib import Path

from .config import get_gemini_key, GEMINI_VISION_MODEL
from .canon_rules import build_canon_checklist_prompt, HARD_FAIL_CODES

log = logging.getLogger("mikage.gemini_gate")


def final_gate(image_path: str, pixel_report: dict, job_dir: Path) -> dict:
    """
    Send image to Gemini for visual canon compliance check.

    Returns:
        {
            "gemini_executed": bool,
            "parse_ok": bool,
            "pass_fail": "PASS" / "FAIL",
            "final_decision": "ALLOW" / "REJECT",
            "checks": [...],
            "reasoning": str,
        }
    """
    path = Path(image_path)
    if not path.exists():
        return {
            "gemini_executed": False,
            "parse_ok": False,
            "pass_fail": "FAIL",
            "final_decision": "REJECT",
            "error": f"Image not found: {image_path}",
        }

    # ── Encode image ──
    image_bytes = path.read_bytes()
    image_b64 = base64.b64encode(image_bytes).decode("utf-8")

    # Detect mime type
    suffix = path.suffix.lower()
    mime_map = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}
    mime_type = mime_map.get(suffix, "image/png")

    # ── Build prompt ──
    canon_checklist = build_canon_checklist_prompt()

    pixel_summary = ""
    if pixel_report and "error" not in pixel_report:
        pixel_summary = f"""
Pixel analysis results (automated):
- crimson_ratio: {pixel_report.get('crimson_ratio', 'N/A')}
- shadow_ratio: {pixel_report.get('shadow_ratio', 'N/A')}
- mean_luminance: {pixel_report.get('mean_luminance', 'N/A')}
- edge_activity: {pixel_report.get('edge_activity', 'N/A')}
- magenta_neon_spill: {pixel_report.get('magenta_neon_spill', 'N/A')}
"""

    prompt = f"""You are the FINAL GATE for the MIKAGE ZENITH visual pipeline.
You must decide: ALLOW or REJECT this image.

{canon_checklist}

{pixel_summary}

HARD FAIL codes (instant REJECT if any fail): {', '.join(HARD_FAIL_CODES)}

After checking all rules, output JSON:
{{
  "checks": [
    {{"code": "T1", "pass": true, "reason": "..."}},
    ...
  ],
  "hard_fail_count": 0,
  "pass_fail": "PASS",
  "final_decision": "ALLOW",
  "reasoning": "One sentence summary"
}}

If ANY hard fail code fails, final_decision MUST be "REJECT".
Be strict. This is brand identity — no drift allowed."""

    # ── Call Gemini Vision ──
    key = get_gemini_key()
    url = f"https://generativelanguage.googleapis.com/v1beta/models/{GEMINI_VISION_MODEL}:generateContent?key={key}"

    body = {
        "contents": [{
            "role": "user",
            "parts": [
                {"inlineData": {"mimeType": mime_type, "data": image_b64}},
                {"text": prompt},
            ]
        }],
        "generationConfig": {
            "temperature": 0.1,
            "responseMimeType": "application/json",
        },
    }

    log.info(f"Gemini gate: sending image ({len(image_bytes)} bytes) for final check...")

    try:
        r = requests.post(url, json=body, timeout=120)

        if r.status_code == 403:
            log.error("Gemini 403 — API key invalid or vision not enabled")
            return {
                "gemini_executed": False,
                "parse_ok": False,
                "pass_fail": "FAIL",
                "final_decision": "REJECT",
                "error": "Gemini 403 — check API key",
            }

        if r.status_code != 200:
            log.error(f"Gemini HTTP {r.status_code}: {r.text[:300]}")
            return {
                "gemini_executed": False,
                "parse_ok": False,
                "pass_fail": "FAIL",
                "final_decision": "REJECT",
                "error": f"Gemini HTTP {r.status_code}",
            }

        data = r.json()
        text = data["candidates"][0]["content"]["parts"][0]["text"]

        # ── Parse response ──
        try:
            gate_result = json.loads(text)
            log.info(f"Gemini gate: decision={gate_result.get('final_decision', '?')}")

            # Save to job dir
            gate_path = job_dir / "gemini_gate_report.json"
            gate_path.write_text(json.dumps(gate_result, indent=2))

            return {
                "gemini_executed": True,
                "parse_ok": True,
                "pass_fail": gate_result.get("pass_fail", "FAIL"),
                "final_decision": gate_result.get("final_decision", "REJECT"),
                "hard_fail_count": gate_result.get("hard_fail_count", -1),
                "checks": gate_result.get("checks", []),
                "reasoning": gate_result.get("reasoning", ""),
            }

        except json.JSONDecodeError as e:
            log.error(f"Gemini returned invalid JSON: {e}")
            return {
                "gemini_executed": True,
                "parse_ok": False,
                "pass_fail": "FAIL",
                "final_decision": "REJECT",
                "error": f"Invalid JSON from Gemini: {e}",
                "raw_text": text[:500],
            }

    except Exception as e:
        log.error(f"Gemini gate exception: {e}")
        return {
            "gemini_executed": False,
            "parse_ok": False,
            "pass_fail": "FAIL",
            "final_decision": "REJECT",
            "error": str(e),
        }
