"""
MIKAGE PIPELINE — orchestrator.py
Runs the full end-to-end pipeline:
  Gemini intake -> Claude spec -> Fooocus render ->
  Post-validator -> Gemini final gate -> ALLOW/REJECT

Usage:
    python -m pipeline.orchestrator "porcelain kitsune mask, crimson seam, obsidian void"
    python -m pipeline.orchestrator --brief "your creative brief here"
"""

import json
import time
import logging
import argparse
import uuid
from pathlib import Path
from datetime import datetime

# Setup logging BEFORE imports
logging.basicConfig(
    level=logging.INFO,
    format="[%(asctime)s] %(levelname)s — %(name)s — %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("mikage.orchestrator")

from .config import RUNS_DIR, log_key_presence
from .gemini_intake import intake
from .claude_spec import build_fooocus_spec
from .render_handler import render
from .validator import validate
from .gemini_gate import final_gate


def generate_job_id() -> str:
    """Generate unique job ID."""
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    short_uuid = uuid.uuid4().hex[:6]
    return f"{ts}_{short_uuid}"


def run_pipeline(brief: str) -> dict:
    """
    Execute the full Mikage pipeline.

    Args:
        brief: Creative brief text

    Returns:
        Full pipeline result dict
    """
    job_id = generate_job_id()
    job_dir = RUNS_DIR / job_id
    job_dir.mkdir(parents=True, exist_ok=True)

    log.info(f"{'='*60}")
    log.info(f"MIKAGE PIPELINE — Job: {job_id}")
    log.info(f"Brief: {brief[:100]}...")
    log.info(f"Output: {job_dir}")
    log.info(f"{'='*60}")

    # Log key presence (never values)
    log_key_presence()

    pipeline_start = time.time()
    result = {
        "job_id": job_id,
        "job_dir": str(job_dir),
        "brief": brief,
        "stages": {},
        "final_decision": "REJECT",  # Default
        "output_files": [],
    }

    # ── STAGE 1: Gemini Intake ──
    log.info("\n>>> STAGE 1: Gemini Intake")
    stage_start = time.time()
    intake_result = intake(brief)
    result["stages"]["gemini_intake"] = {
        **intake_result,
        "duration": round(time.time() - stage_start, 1),
    }

    if intake_result["status"] != "success":
        log.error(f"STAGE 1 FAILED: {intake_result.get('error')}")
        result["final_decision"] = "REJECT"
        result["reject_reason"] = f"Gemini intake failed: {intake_result.get('error')}"
        save_result(result, job_dir)
        return result

    spec = intake_result["spec"]

    # Save spec
    spec_path = job_dir / "spec.json"
    spec_path.write_text(json.dumps(spec, indent=2))
    log.info(f"  Spec saved: {spec_path}")

    # ── STAGE 2: Claude Spec Writer ──
    log.info("\n>>> STAGE 2: Claude Spec Writer")
    stage_start = time.time()
    fooocus_spec = build_fooocus_spec(spec)
    result["stages"]["claude_spec"] = {
        "status": "success",
        "prompt_length": len(fooocus_spec["prompt"]),
        "duration": round(time.time() - stage_start, 1),
    }

    # Save prompt
    prompt_path = job_dir / "prompt.json"
    prompt_path.write_text(json.dumps(fooocus_spec, indent=2))
    log.info(f"  Prompt saved: {prompt_path}")
    log.info(f"  Prompt: {fooocus_spec['prompt'][:120]}...")

    # ── STAGE 3: Fooocus Render ──
    log.info("\n>>> STAGE 3: Fooocus Render")
    stage_start = time.time()
    render_result = render(
        prompt=fooocus_spec["prompt"],
        negative_prompt=fooocus_spec["negative_prompt"],
        params=fooocus_spec["params"],
        job_dir=job_dir,
    )
    result["stages"]["render"] = {
        **render_result,
        "duration": round(time.time() - stage_start, 1),
    }

    if render_result["status"] != "success":
        log.error(f"STAGE 3 FAILED: {render_result.get('error')}")
        result["final_decision"] = "REJECT"
        result["reject_reason"] = f"Render failed: {render_result.get('error')}"
        save_result(result, job_dir)
        return result

    output_path = render_result.get("output_path", "")
    log.info(f"  Rendered: {output_path}")

    # ── STAGE 4: Post-Validator ──
    log.info("\n>>> STAGE 4: Post-Validator")
    stage_start = time.time()
    val_result = validate(output_path, job_dir)
    result["stages"]["validator"] = {
        **val_result,
        "duration": round(time.time() - stage_start, 1),
    }

    if val_result["status"] == "fail":
        log.error(f"STAGE 4 FAILED: hard_fails={val_result.get('hard_fails')}")
        result["final_decision"] = "REJECT"
        result["reject_reason"] = f"Validator hard fail: {val_result.get('hard_fails')}"
        save_result(result, job_dir)
        return result

    pixel_report = val_result.get("pixel_report", {})

    # ── STAGE 5: Gemini Final Gate ──
    log.info("\n>>> STAGE 5: Gemini Final Gate")
    stage_start = time.time()
    gate_result = final_gate(output_path, pixel_report, job_dir)
    result["stages"]["gemini_gate"] = {
        **gate_result,
        "duration": round(time.time() - stage_start, 1),
    }

    if gate_result["final_decision"] != "ALLOW":
        log.error(f"STAGE 5: REJECTED — {gate_result.get('reasoning', 'no reason')}")
        result["final_decision"] = "REJECT"
        result["reject_reason"] = f"Gemini gate: {gate_result.get('reasoning')}"
    else:
        log.info("STAGE 5: ALLOWED!")
        result["final_decision"] = "ALLOW"
        result["output_files"] = ["output.png"]

    # ── Summary ──
    total_time = round(time.time() - pipeline_start, 1)
    result["total_duration"] = total_time

    save_result(result, job_dir)

    log.info(f"\n{'='*60}")
    log.info(f"PIPELINE COMPLETE — {result['final_decision']}")
    log.info(f"  Job:      {job_id}")
    log.info(f"  Duration: {total_time}s")
    log.info(f"  Output:   {job_dir}")
    if result["final_decision"] == "ALLOW":
        log.info(f"  Files:    {result['output_files']}")
    else:
        log.info(f"  Reason:   {result.get('reject_reason', 'unknown')}")
    log.info(f"{'='*60}")

    return result


def save_result(result: dict, job_dir: Path):
    """Save pipeline result to job directory."""
    report_path = job_dir / "report.json"
    # Clean non-serializable values
    clean = json.loads(json.dumps(result, default=str))
    report_path.write_text(json.dumps(clean, indent=2))


# ── CLI Entry Point ──
def main():
    parser = argparse.ArgumentParser(description="MIKAGE ZENITH Pipeline")
    parser.add_argument("brief", nargs="?", default=None, help="Creative brief")
    parser.add_argument("--brief", "-b", dest="brief_flag", default=None, help="Creative brief (flag)")
    args = parser.parse_args()

    brief = args.brief or args.brief_flag
    if not brief:
        brief = "porcelain kitsune mask, thin crimson seam at jawline, obsidian void background, chiaroscuro dramatic shadow, industrial precision"

    result = run_pipeline(brief)

    # Print final summary
    print(f"\n{'='*40}")
    print(f"Decision: {result['final_decision']}")
    print(f"Job ID:   {result['job_id']}")
    print(f"Duration: {result['total_duration']}s")
    print(f"{'='*40}")


if __name__ == "__main__":
    main()
