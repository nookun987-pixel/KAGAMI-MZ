"""
MIKAGE PIPELINE — claude_spec.py
Converts Gemini intake spec into Fooocus-ready prompt + render params.
Uses local logic (no API call needed — the spec is deterministic).
"""

import logging

log = logging.getLogger("mikage.claude_spec")

# ── MIKAGE PROMPT TEMPLATE ──
BASE_POSITIVE = (
    "masterpiece, best quality, ultra detailed, photorealistic, "
    "8k uhd, studio photography, professional lighting, "
    "chiaroscuro dramatic lighting, deep shadows, "
    "porcelain ceramic material, fine ceramic texture, "
    "matte porcelain surface, museum quality, "
    "negative space, clean composition, minimal, "
    "product photography, centered subject"
)

BASE_NEGATIVE = (
    "human eyes, iris, pupil, sclera, facial expression, smile, frown, "
    "plastic, PVC, glossy plastic, plaster, CGI, "
    "toon shading, cel shading, anime, cartoon, illustration, "
    "neon, RGB, cyberpunk, glitch, chromatic aberration, "
    "abstract, unrecognizable, blurry, noise, artifacts, "
    "watermark, logo, text, signature, "
    "pure white background, pure black background, "
    "bloom, lens flare, glow, neon glow, "
    "low quality, worst quality, jpeg artifacts, "
    "deformed, distorted, asymmetric"
)


def build_fooocus_spec(intake_spec: dict) -> dict:
    """
    Convert Gemini intake spec into Fooocus render parameters.

    Returns:
        {
            "prompt": str,
            "negative_prompt": str,
            "params": {
                "image_number": int,
                "guidance_scale": float,
                "sharpness": float,
                "performance": str,
                "aspect_ratios": str,
                "styles": list,
                "base_model": str,
            }
        }
    """
    subject = intake_spec.get("subject", "porcelain kitsune mask")
    material = intake_spec.get("material", "ceramic porcelain")
    color_accent = intake_spec.get("color_accent", "thin crimson #E60000 seam lines")
    background = intake_spec.get("background", "obsidian")
    lighting = intake_spec.get("lighting", "chiaroscuro 4:1 ratio")
    mood = intake_spec.get("mood", "low energy high control")
    negative_hints = intake_spec.get("negative_hints", "")
    prompt_seed = intake_spec.get("prompt_seed", "")

    # ── Build positive prompt ──
    subject_desc = f"{subject}, {material} material"
    accent_desc = f"subtle {color_accent}"

    if background.lower() in ["obsidian", "dark", "black"]:
        bg_desc = "dark obsidian #0A0A0A background"
    else:
        bg_desc = "soft porcelain #FAFAFA background"

    lighting_desc = f"{lighting}, dramatic shadow"
    mood_desc = mood

    # Use prompt_seed if Gemini provided a good one
    if prompt_seed and len(prompt_seed) > 20:
        core_prompt = prompt_seed
    else:
        core_prompt = f"{subject_desc}, {accent_desc}, {bg_desc}, {lighting_desc}"

    full_prompt = f"{core_prompt}, {mood_desc}, {BASE_POSITIVE}"

    # ── Build negative prompt ──
    full_negative = BASE_NEGATIVE
    if negative_hints:
        full_negative = f"{negative_hints}, {full_negative}"

    # ── Render params ──
    params = {
        "image_number": 1,
        "guidance_scale": 4.0,
        "sharpness": 2.0,
        "performance": "Quality",
        "aspect_ratios": "1152\u00d7896",  # 9:7 landscape (Mikage standard)
        "styles": ["Fooocus V2", "Fooocus Enhance", "Fooocus Sharp"],
        "base_model": "juggernautXL_v8Rundiffusion.safetensors",
        "seed": -1,
    }

    log.info(f"Spec built: prompt length={len(full_prompt)}, negative length={len(full_negative)}")

    return {
        "prompt": full_prompt,
        "negative_prompt": full_negative,
        "params": params,
    }
