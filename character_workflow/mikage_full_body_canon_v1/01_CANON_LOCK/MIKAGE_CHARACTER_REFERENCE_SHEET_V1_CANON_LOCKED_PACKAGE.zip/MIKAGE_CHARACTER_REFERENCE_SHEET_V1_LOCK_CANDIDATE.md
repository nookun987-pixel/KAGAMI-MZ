# MIKAGE CHARACTER REFERENCE SHEET V1 — LOCK CANDIDATE

## 1. Purpose

This document promotes the current Mikage character reference work from draft review to **LOCK_CANDIDATE** status.

This is **not** final canon lock yet. It requires operator review.

## 2. Source Files

```text
REFERENCE_SHEET = MIKAGE_CHARACTER_REFERENCE_SHEET_V1_DRAFT.jpg
REFERENCE_REPORT = MIKAGE_CHARACTER_REFERENCE_SHEET_V1_DRAFT_REPORT.json
```

## 3. Current Status

```text
OVERALL_STATUS = LOCK_CANDIDATE_CREATED
IDENTITY_STATUS = STABLE_3_POSES_PASS
CANON_LOCK = PENDING_OPERATOR_REVIEW
```

## 4. Core Assets

```text
PRIMARY_V2 = PRIMARY_CANDIDATE_PASS
POSE_TEST_01 = STABLE_POSE_PASS
POSE_TEST_03 = PASS_AS_CORE_POSE_CANDIDATE
```

## 5. Variant Asset

```text
POSE_TEST_02 = CONDITIONAL_PASS_AS_DRAMATIC_VARIANT
CORE_CANON = NO
```

Pose Test 02 may be kept for poster/variant/moodboard use, but it must not be used as the character bible/core canon pose.

## 6. Hard Identity Rules

```text
- Smooth faceless white porcelain helmet
- Two thin horizontal black sensor slits only
- No human eyes, mouth, nose, lips, skin, or face expression
- Long heavy black hair mass
- White angular armor with black underlayer
- Minimal electric violet accents
- Massive straight rectangular slab sword, not katana
- Void black background / premium dark lighting
```

## 7. Risk Controls

```text
- Do not treat AI infographic text as proof
- Use real contact sheets/crops for verification
- Pose Test 02 is variant only, not core canon
- Hair noise below 75px remains a known risk
- Armor/female-mecha/fantasy-knight signal must be reduced in future formal canon assets
```

## 8. Operator Review Required

```text
[ ] Reference sheet visually matches Mikage identity
[ ] Pose Test 02 is clearly labeled as variant only
[ ] Core assets are Primary V2, Pose 01, Pose 03
[ ] No AI infographic proof is used as canon evidence
[ ] Operator approves proceed to CANON_LOCKED_REFERENCE_V1
```

## 9. Next Safe Task

If operator passes:

```text
CREATE_MIKAGE_CHARACTER_REFERENCE_SHEET_V1_CANON_LOCKED_PACKAGE
```

If operator fails:

```text
PATCH_REFERENCE_SHEET_LABELS_OR_REBUILD_SPECIFIC_FAILED_ASSET_ONLY
```

## 10. Working Verdict

```text
Mikage full-body identity has enough stability to become LOCK_CANDIDATE.
Final canon lock remains blocked until operator review confirms the draft sheet.
```
